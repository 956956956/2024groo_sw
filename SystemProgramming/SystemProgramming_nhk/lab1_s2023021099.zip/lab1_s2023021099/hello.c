#include<stdio.h>
int main(){
	printf("hello knu\n");
	return 0;
}
