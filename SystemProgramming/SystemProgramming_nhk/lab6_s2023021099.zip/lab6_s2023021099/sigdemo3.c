#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <time.h>

time_t start_time;

void signal_handler(int signum) {
    time_t current_time = time(NULL);
    double elapsed = difftime(current_time, start_time);
    printf("Currently elapsed time: %.0f sec(s)\n",elapsed);
}

int main() {
    start_time = time(NULL);

    signal(SIGINT, signal_handler);

    printf("you can't stop me!\n");
    while (1) {
        printf("haha\n");
        sleep(1);
    }

    return 0;
}

