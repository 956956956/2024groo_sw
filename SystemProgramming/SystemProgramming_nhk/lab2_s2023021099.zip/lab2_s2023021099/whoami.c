#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<pwd.h>

int main(){
	uid_t user_id = getuid();
	struct passwd *user_info = getpwuid(user_id);

	if(user_info == NULL){
		perror("getuid|getpwuid");
		exit(1);
	}
	printf("%s\n",user_info->pw_name);
	return 0;

}
