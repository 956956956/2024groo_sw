#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <unistd.h>

#define LINELEN 512

void do_more(FILE *);
int see_more();

int main(int ac, char *av[]) {
    FILE *fp;

    if (ac == 1)
        do_more(stdin);
    else
        while (--ac)
            if ((fp = fopen(*++av, "r")) != NULL) {
                do_more(fp);
                fclose(fp);
            } else
                exit(1);

    return 0;
}

void do_more(FILE *fp) {
    char line[LINELEN];
    int num_of_lines = 0;
    int see_more(), reply;
    struct winsize w;

    while (fgets(line, LINELEN, fp)) {
	if (ioctl(0, TIOCGWINSZ, &w) == -1) {
        	perror("ioctl");
        	exit(1);
    	}
    	int PAGELEN = w.ws_row - 1;
    	if (num_of_lines == PAGELEN) {
       		reply = see_more();
        if (reply == 0)
                break;
	if(reply == LINELEN)
		reply = PAGELEN;
        num_of_lines -= reply;
        }
        if (fputs(line, stdout) == EOF)
            	exit(1);
        num_of_lines++;
    }
}

int see_more() {
    int c;

    printf("\033[7m more? \033[m");
    while ((c = getchar()) != EOF) {
	    printf("\n");
        if (c == 'q')
            return 0;
        if (c == ' ')
            return LINELEN;
        if (c == '\n')
            return 1;
    }
    return 0;
}

